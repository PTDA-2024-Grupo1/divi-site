#!/bin/bash
java -jar ./divi.jar "$@"