#!/bin/bash
echo "Installing Divi Expense Tracker..."

# Define installation directory
INSTALL_DIR="/opt/divi"

# Create the installation directory
sudo mkdir -p "$INSTALL_DIR"

# Copy application files
sudo cp divi.jar "$INSTALL_DIR"
sudo cp -r src/main/resources/images "$INSTALL_DIR"  # Copy the entire images directory
sudo cp run-divi.sh "$INSTALL_DIR"
sudo chmod +x "$INSTALL_DIR/run-divi.sh"

# Create a symlink for global access
sudo ln -sf "$INSTALL_DIR/run-divi.sh" /usr/local/bin/divi

echo "Installation complete. Run 'divi' to start the application."